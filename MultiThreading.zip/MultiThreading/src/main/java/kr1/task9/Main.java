package kr1.task9;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        var cars = new Car[100];
        var trafficLight = new TrafficLight(cars);

        for (int i = 0; i < cars.length; i++) {
            cars[i] = new Car(trafficLight);
        }

        trafficLight.start();
        for (Car car : cars) {
            car.start();
        }

        for (Car car : cars) {
            car.join();
        }
        trafficLight.join();
    }
}

enum Color {
    RED,
    YELLOW,
    GREEN
}

@Getter
@RequiredArgsConstructor
class Car extends Thread {
    private final TrafficLight trafficLight;
    @Getter
    private static int count = 0;


    private void go() {
        System.out.println("Car has passed!!!");
    }

    @Override
    public void run() {
        while (count < 1000) {
            try {
                synchronized (trafficLight) {
                    while (trafficLight.getColor() != Color.GREEN) {
                        try {
                            trafficLight.wait();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    sleep(2);
                    go();
                    count++;
                }
                sleep(400);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}

@Getter
class TrafficLight extends Thread {
    private Color color;
    private Car[] cars;

    public TrafficLight(Car[] cars) {
        this.color = Color.GREEN;
        this.cars = cars;
    }

    @Override
    public void run() {
        while (Car.getCount() < 1000) {
            try {
                sleep(60);
                color = Color.YELLOW;
                System.out.println(color.toString());
                sleep(10);
                color = Color.RED;
                System.out.println(color.toString());
                sleep(40);
                color = Color.YELLOW;
                System.out.println(color.toString());
                sleep(10);
                color = Color.GREEN;
                System.out.println(color.toString());
                synchronized (this) {
                    notifyAll();
                }
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
