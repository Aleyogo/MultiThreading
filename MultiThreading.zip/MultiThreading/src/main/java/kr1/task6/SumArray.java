package kr1.task6;

import java.util.concurrent.*;

public class SumArray {
    private static final int ARRAY_SIZE = 50000;
    private static final int TASK_SIZE = 500;
    private static final int THREAD_COUNT = 4;

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        var array = new double[ARRAY_SIZE];
        for (int i = 0; i < ARRAY_SIZE; i++) {
            array[i] = Math.random();
        }

        var executorService = Executors.newFixedThreadPool(THREAD_COUNT);
        double sum = 0;

        for (int i = 0; i < ARRAY_SIZE; i += TASK_SIZE) {
            int endIndex = Math.min(i + TASK_SIZE, ARRAY_SIZE);
            Callable<Double> task = new SummingParts(array, i, endIndex);
            var futureResult = executorService.submit(task);
            sum += futureResult.get();
        }

        executorService.shutdown();
        System.out.println("Сума елементів масиву: " + sum);
    }
}

class SummingParts implements Callable<Double> {
    private final double[] array;
    private final int startIndex;
    private final int endIndex;

    public SummingParts(double[] array, int startIndex, int endIndex) {
        this.array = array;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
    }

    @Override
    public Double call() {
        double sum = 0;
        for (int i = startIndex; i < endIndex; i++) {
            sum += array[i];
        }
        return sum;
    }
}

