package kr1.task17;

import lombok.Getter;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        var stateObject = new StateObject();
        var threadA = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(100);
                    State newState = stateObject.getState() == State.S ? State.Z : State.S;
                    System.out.println("Thread A changed state to " + newState);
                    stateObject.setState(newState);
                } catch (InterruptedException e) {
                    System.err.println("Thread A has been interrupted.");
                    break;
                }
            }
        });
        var threadB = new Thread(() -> {
            while (true) {
                try {
                    synchronized (stateObject) {
                        while (stateObject.getState() != State.S) {
                            stateObject.wait();
                        }
                        for (int i = 100; i > 0; i--) {
                            System.out.println("Countdown: " + i);
                            Thread.sleep(1);
                        }
                        System.out.println("Thread B has been suspended.");
                        stateObject.wait();
                        System.out.println("Thread B has been resumed.");
                    }
                } catch (InterruptedException e) {
                    System.err.println("Thread B has been interrupted.");
                    break;
                }
            }
        });
        threadA.start();
        threadB.start();
        Thread.sleep(1000);
        threadA.interrupt();
        threadB.interrupt();
    }

    @Getter
    private static class StateObject {
        private State state = State.S;

        public synchronized void setState(State state) {
            this.state = state;
            notifyAll();
        }
    }

    private enum State {
        S,
        Z
    }
}
