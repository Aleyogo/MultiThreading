package exam;

import mpi.MPI;
import mpi.MPIException;

import java.util.Arrays;

public class Main {
    static final int MASTER = 0;
    static final int size = 12;

    public static void main(String[] args) throws MPIException {
        MPI.Init(args);

        var curProcess = MPI.COMM_WORLD.Rank();

        var array = new int[size];

        Arrays.fill(array, 1);

        var localSum = 0;

        var recvBuf = new int[2];
        MPI.COMM_WORLD.Scatter(array, 0, 2, MPI.INT, recvBuf, 0, 2, MPI.INT, MASTER);
        for (int i = 0; i < 2; i++) {
            localSum += recvBuf[i];
        }

        var sum = new int[1];
        MPI.COMM_WORLD.Reduce(new int[]{localSum}, 0, sum, 0, 1, MPI.INT, MPI.SUM, 0);

        if (curProcess == 0) {
            System.out.println("Сума елементів: " + sum[0]);
        }

        MPI.Finalize();
    }
}
