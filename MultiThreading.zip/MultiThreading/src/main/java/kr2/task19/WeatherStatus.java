package kr2.task19;

import mpi.*;

public class WeatherStatus {
    public static void main(String[] args) throws MPIException {
        MPI.Init(args);
        var rank = MPI.COMM_WORLD.Rank();
        System.out.println(rank);

        if (rank == 2) {
            int[] temperatureData = new int[30];
            for (int i = 0; i < temperatureData.length; i++) {
                temperatureData[i] = i + 1;
            }
            MPI.COMM_WORLD.Send(temperatureData, 0, temperatureData.length, MPI.INT, 0, 0);
        } else if (rank == 0) {
            int[] temperatureData = new int[30];
            MPI.COMM_WORLD.Recv(temperatureData, 0, temperatureData.length, MPI.INT, 2, 0);
            for (int i = 0; i < temperatureData.length; i++)
                System.out.println("Day " + (i + 1) + ": " + temperatureData[i]);
        }

        MPI.Finalize();
    }
}

