package kr2;


import mpi.MPI;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        MPI.Init(args);
        int rank = MPI.COMM_WORLD.Rank();
        int size = MPI.COMM_WORLD.Size();
        int n = 20;
        int chunkSize = n/size;

        int[][] A = new int[n][n];
        int[][] B = new int[n][n];
        int[][] C = new int[n][n];

        // Initialize A and B with random integer values
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                A[i][j] = (int) (Math.random() * 100);
                B[i][j] = (int) (Math.random() * 100);
            }
        }

        // Scatter A and B among the processes
        int[] sendcounts = new int[size];
        int[] displs = new int[size];
        for (int i = 0; i < size; i++) {
            sendcounts[i] = chunkSize * n;
            displs[i] = i * chunkSize * n;
        }
        int[] AChunk = new int[chunkSize * n];
        int[] BChunk = new int[chunkSize * n];
        MPI.COMM_WORLD.Scatterv(A, 0, sendcounts, displs, MPI.INT, AChunk, 0, chunkSize * n, MPI.INT, 0);
        MPI.COMM_WORLD.Scatterv(B, 0, sendcounts, displs, MPI.INT, BChunk, 0, chunkSize * n, MPI.INT, 0);

        // Compute the local sums of the rows of A and B
        int[] sumA = new int[chunkSize];
        int[] sumB = new int[chunkSize];
        for (int i = 0; i < chunkSize; i++) {
            for (int j = 0; j < n; j++) {
                sumA[i] += AChunk[i*n + j];
                sumB[i] += BChunk[i*n + j];
            }
        }

        // Reduce the sums of A and B to the root process
        int[] globalSumA = new int[n];
        int[] globalSumB = new int[n];
        MPI.COMM_WORLD.Allreduce(sumA, 0, globalSumA, 0, chunkSize, MPI.INT, MPI.SUM);
        MPI.COMM_WORLD.Allreduce(sumB, 0, globalSumB, 0, chunkSize, MPI.INT, MPI.SUM);

        // Compute the local values of C
        int[] localC = new int[chunkSize];
        for (int i = 0; i < chunkSize; i++) {
            localC[i] = 0;
            for (int j = 0; j < n; j++) {
                localC[i] += AChunk[i*n + j] * globalSumB[j];
                localC[i] += BChunk[i*n + j] * globalSumA[j];
            }
        }

        // Gather the local values of C to the root process
        int[] recvcounts = new int[size];
        for (int i = 0; i < size - 1; i++) {
            recvcounts[i] = chunkSize;
        }
        recvcounts[size - 1] = n - (size - 1) * chunkSize;
        MPI.COMM_WORLD.Gatherv(localC, 0, recvcounts[rank], MPI.INT, C, 0, recvcounts, displs, MPI.INT, 0);

        MPI.Finalize();

    }
}
