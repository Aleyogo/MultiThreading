package kr2.task18;

import mpi.*;

public class SumArray {
    public static void main(String[] args) throws MPIException {
//        MPI.Init(args);
//        var rank = MPI.COMM_WORLD.Rank();
//        var size = MPI.COMM_WORLD.Size();
//        int[] arr = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
//        var localSum = 0;
//        for (int i = rank; i < arr.length; i += size) {
//            localSum += arr[i];
//        }
//        int[] sums = new int[size];
//        MPI.COMM_WORLD.Allgather(new int[] {localSum}, 0, 1, MPI.INT, sums, 0, 1, MPI.INT);
//        var sum = 0;
//        for (int i = 0; i < size; i++) {
//            sum += sums[i];
//        }
//        System.out.println("Process " + rank + " local sum: " + localSum);
//        System.out.println("Process " + rank + " total sum: " + sum);
//        MPI.Finalize();
    }
}