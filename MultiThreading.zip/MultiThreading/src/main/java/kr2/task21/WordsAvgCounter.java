package kr2.task21;

import lombok.AllArgsConstructor;

import java.util.ArrayList;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

@AllArgsConstructor
public class WordsAvgCounter extends RecursiveTask<Double> {

    public static void main(String[] args) {
        ArrayList<String> words = new ArrayList<>();
        words.add("hello");
        words.add("from");
        words.add("the");
        words.add("hell");
        words.add("o");
        ForkJoinPool pool = new ForkJoinPool();
        var task = new WordsAvgCounter(words, 0, words.size());
        var result = pool.invoke(task);
        System.out.println("Average word length: " + result);
    }

    private static final int SIZE = 20;
    private final ArrayList<String> words;
    private final int startIndex;
    private final int endIndex;

    @Override
    protected Double compute() {
        var length = endIndex - startIndex;
        if (length <= SIZE) {
            var sum = 0;
            for (int i = startIndex; i < endIndex; i++) {
                sum += words.get(i).length();
            }
            return (double) (sum / length);
        } else {
            var midIndex = startIndex + length / 2;
            var leftAvg = new WordsAvgCounter(words, startIndex, midIndex);
            var rightAvg = new WordsAvgCounter(words, midIndex, endIndex);
            leftAvg.fork();
            var rightResult = rightAvg.compute();
            var leftResult = leftAvg.join();
            return (leftResult * (midIndex - startIndex) + rightResult * (endIndex - midIndex)) / length;
        }
    }
}

