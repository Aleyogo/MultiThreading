package kr2.task20;

import lombok.AllArgsConstructor;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

@AllArgsConstructor
public class CalcSum extends RecursiveTask<Integer> {

    public static void main(String[] args) {
        int[] numbers = new int[10000];
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = i;
        }
        ForkJoinPool pool = new ForkJoinPool(10);
        var task = new CalcSum(numbers, 0, numbers.length);
        var result = pool.invoke(task);
        System.out.println("Sum of the numbers: " + result);
    }

    private static final int SIZE = 100;
    private final int[] numbers;
    private final int startIndex;
    private final int endIndex;


    @Override
    protected Integer compute() {
        var length = endIndex - startIndex;
        if (length <= SIZE) {
            var sum = 0;
            for (int i = startIndex; i < endIndex; i++) {
                sum += numbers[i];
            }
            return sum;
        } else {
            var midIndex = startIndex + length / 2;
            var leftSum = new CalcSum(numbers, startIndex, midIndex);
            var rightSum = new CalcSum(numbers, midIndex, endIndex);
            leftSum.fork();
            var rightResult = rightSum.compute();
            var leftResult = leftSum.join();
            return leftResult + rightResult;
        }
    }


}

