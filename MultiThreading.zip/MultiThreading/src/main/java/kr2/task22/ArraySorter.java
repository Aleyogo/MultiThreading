package kr2.task22;

import mpi.*;

import java.util.Arrays;

public class ArraySorter {

    public static void main(String[] args) throws MPIException {
        MPI.Init(args);
        var size = MPI.COMM_WORLD.Size(); // 6
        var peaceSize = 3;
        final int ROOT = 0;
        if (MPI.COMM_WORLD.Rank() == ROOT) {
            String[] arr = {"Ad", "nisi", "do", "non", "excepteur", "consectetur", "consequat", "consectetur", "laborum", "est", "laboris",
                    "duis", "excepteur", "in", "Qui", "enim", "exercitation", "officia"};
            String[] first = new String[size - 1];
            for (int i = 1; i < size; i++) {
                MPI.COMM_WORLD.Send(arr, (i - 1) * peaceSize, peaceSize, MPI.OBJECT, i, 100);
            }
            for (int i = 1; i < size; i++) {
                MPI.COMM_WORLD.Recv(first, i - 1, 1, MPI.OBJECT, i, 100);
            }
            for (int i = 1; i < size; i++) {
                System.out.println(first[i - 1]);
            }
        } else {
            String[] buffer = new String[peaceSize];
            MPI.COMM_WORLD.Recv(buffer, 0, peaceSize, MPI.OBJECT, ROOT, 100);
            Arrays.sort(buffer);
            MPI.COMM_WORLD.Send(buffer, 0, 1, MPI.OBJECT, ROOT, 100);
        }
        MPI.Finalize();
    }
}

